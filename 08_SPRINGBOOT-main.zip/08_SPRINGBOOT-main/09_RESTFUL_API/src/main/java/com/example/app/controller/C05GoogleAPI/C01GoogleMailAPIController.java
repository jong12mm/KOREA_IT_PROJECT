package com.example.app.controller.C05GoogleAPI;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@Slf4j
@RequestMapping("/google")
public class C01GoogleMailAPIController {

    @GetMapping("/mail/main")
    public void main() {
        log.info("GET /google/mail/main..");
    }

    @Autowired
    JavaMailSender javaMailSender;

    @GetMapping("/mail/req")
    public String req(@RequestParam("email") String email, @RequestParam("text") String text) {
        log.info("GET /google/mail/req..email : " + email + " text : " + text);
        log.info("javaMailSender : " + javaMailSender);
        // 메세지 지정
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo("jong12mm@naver.com");
        message.setSubject("반갑디");
        message.setText("ㅎㅇㅎㅇ");


        javaMailSender.send(message);

        return "redirect:/google/mail/main?meesage='전송성공'";
    }
}
