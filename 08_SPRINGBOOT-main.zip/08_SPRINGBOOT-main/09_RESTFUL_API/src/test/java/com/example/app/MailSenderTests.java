package com.example.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import java.util.Properties;

@SpringBootTest
public class MailSenderTests {

    @Test
    public void t1() {
        // 메일설정
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        mailSender.setHost("smtp.gmail.com");
        mailSender.setPort(587);
        mailSender.setUsername("jongmm8@gmail.com");
        mailSender.setPassword("wziz zrdv aibk fwfp");

        Properties mailProps = new Properties();
        mailProps.put("mail.smtp.auth","true");
        mailProps.put("mail.smtp.starttls.enable","true");
        mailSender.setJavaMailProperties(mailProps);

        // 메세지 지정
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo("rjsan56@naver.com");
        message.setSubject("반갑디");
        message.setText("ㅎㅇㅎㅇ");

        // 메일발성
        mailSender.send(message);

    }
}
