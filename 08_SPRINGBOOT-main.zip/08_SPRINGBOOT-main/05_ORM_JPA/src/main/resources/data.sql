insert ignore into a values(1,11);
insert ignore into a values(2,22);
