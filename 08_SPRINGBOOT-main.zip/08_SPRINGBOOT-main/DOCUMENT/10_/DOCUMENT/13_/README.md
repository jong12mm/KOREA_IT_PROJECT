

---
#
---

FULLCALENDAR INIT
---
> <br>

|-|
|-|
|<img widt=500px src="./IMG/01_/1.png" />|
|<img widt=500px src="./IMG/01_/2.png" />|
|<img widt=500px src="./IMG/01_/3.png" />|
|<img widt=500px src="./IMG/01_/4.png" />|
|<img widt=500px src="./IMG/01_/5.png" />|
|<img widt=500px src="./IMG/01_/6.png" />|
|<img widt=500px src="./IMG/01_/7.png" />|

```

```


---
#
---

GOOGLE CALENDAR SETTING
---
> - <br>

|-|
|-|
|<img widt=500px src="./IMG/02_/1.png" />|
|<img widt=500px src="./IMG/02_/2.png" />|
|<img widt=500px src="./IMG/02_/3.png" />|
|<img widt=500px src="./IMG/02_/4.png" />|
|<img widt=500px src="./IMG/02_/5.png" />|
|<img widt=500px src="./IMG/02_/6.png" />|
|<img widt=500px src="./IMG/02_/7.png" />|
|<img widt=500px src="./IMG/02_/8.png" />|
|<img widt=500px src="./IMG/02_/9.png" />|
|<img widt=500px src="./IMG/02_/10.png" />|
|<img widt=500px src="./IMG/02_/11.png" />|
|<img widt=500px src="./IMG/02_/12.png" />|
|<img widt=500px src="./IMG/02_/13.png" />|
|<img widt=500px src="./IMG/02_/14.png" />|
|<img widt=500px src="./IMG/02_/15.png" />|
|<img widt=500px src="./IMG/02_/16.png" />|
|<img widt=500px src="./IMG/02_/17.png" />|
|<img widt=500px src="./IMG/02_/18.png" />|
|<img widt=500px src="./IMG/02_/19.png" />|
|<img widt=500px src="./IMG/02_/20.png" />|
|<img widt=500px src="./IMG/02_/21.png" />|
|<img widt=500px src="./IMG/02_/22.png" />|
|<img widt=500px src="./IMG/02_/23.png" />|
|<img widt=500px src="./IMG/02_/24.png" />|
|<img widt=500px src="./IMG/02_/25.png" />|
|<img widt=500px src="./IMG/02_/26.png" />|
|<img widt=500px src="./IMG/02_/27.png" />|
|<img widt=500px src="./IMG/02_/28.png" />|


```
-
```

---
#
---

CODE에 적용
---
> <br>

|-|
|-|
|<img widt=500px src="./IMG/03_/1.png" />|
|<img widt=500px src="./IMG/03_/2.png" />|
|<img widt=500px src="./IMG/03_/3.png" />|
|<img widt=500px src="./IMG/03_/4.png" />|
|<img widt=500px src="./IMG/03_/5.png" />|
|<img widt=500px src="./IMG/03_/6.png" />|
|<img widt=500px src="./IMG/03_/7.png" />|
|<img widt=500px src="./IMG/03_/8.png" />|
|<img widt=500px src="./IMG/03_/9.png" />|
|<img widt=500px src="./IMG/03_/10.png" />|
|<img widt=500px src="./IMG/03_/11.png" />|
|<img widt=500px src="./IMG/03_/12.png" />|


---
#
---

일정확인
---
> <br>

|-|
|-|
|<img widt=500px src="./IMG/04_/1.png" />|
|<img widt=500px src="./IMG/04_/2.png" />|
|<img widt=500px src="./IMG/04_/3.png" />|
|<img widt=500px src="./IMG/04_/4.png" />|
|<img widt=500px src="./IMG/04_/5.png" />|
|<img widt=500px src="./IMG/04_/6.png" />|
|<img widt=500px src="./IMG/04_/7.png" />|
|<img widt=500px src="./IMG/04_/8.png" />|
|<img widt=500px src="./IMG/04_/9.png" />|
|<img widt=500px src="./IMG/04_/10.png" />|
|<img widt=500px src="./IMG/04_/11.png" />|
|<img widt=500px src="./IMG/04_/12.png" />|
|<img widt=500px src="./IMG/04_/13.png" />|
|<img widt=500px src="./IMG/04_/14.png" />|
|<img widt=500px src="./IMG/04_/15.png" />|
|<img widt=500px src="./IMG/04_/16.png" />|
|<img widt=500px src="./IMG/04_/17.png" />|
|<img widt=500px src="./IMG/04_/18.png" />|
|<img widt=500px src="./IMG/04_/19.png" />|
|<img widt=500px src="./IMG/04_/20.png" />|
|<img widt=500px src="./IMG/04_/21.png" />|
|<img widt=500px src="./IMG/04_/22.png" />|
|<img widt=500px src="./IMG/04_/23.png" />|
|<img widt=500px src="./IMG/04_/24.png" />|
|<img widt=500px src="./IMG/04_/25.png" />|
|<img widt=500px src="./IMG/04_/26.png" />|


