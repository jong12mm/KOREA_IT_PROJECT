





참고링크
---
> <br>

|-|-|
|-|-|
|-|[카카오비즈니스센터](https://business.kakao.com/)|
|**중요**|[카카오비즈니스센터-새 채널 만들기](https://center-pf.kakao.com/)|
|-|[카카오개발센터-기본문서](https://developers.kakao.com/product/kakaoTalkChannel)|
|**중요**|[카카오개발센터-카카오채널추가-JAVASCRIPT_SDK](https://developers.kakao.com/docs/latest/ko/kakaotalk-channel/js#add-channel)|



---
#
---

카카오 채널 API
---
> <br>

|-|
|-|
|<img src="" />|

![20240512151602](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/01d9b91e-6515-47a9-92f8-08cf0e5e11ce)
![20240512151609](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/b34e8b1b-4f84-4503-bba3-9ecc4b033bc1)
![20240512151614](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/bd720895-4351-4d90-915f-df5666a7e2db)
![20240512151740](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/c09214ac-026c-4a60-8b07-98e7c74a263b)
![20240512151756](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/018a01ba-d249-4c68-9be9-af5aecebf024)
![20240512151803](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/4ecc1044-3206-4e48-b70e-df63e67a35f6)
![20240512151818](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/eb4ca1c1-7c0d-4957-b849-c8e236487141)
![20240512151827](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/74f6b12d-3864-4b06-bba5-a78656419620)
![20240512151835](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/d86bba86-6726-43d6-898f-deb9fe3e5c10)
![20240512151841](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/3b16b182-d592-4445-8d78-b1131e842bc1)
![20240512151845](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/f0d0c3bd-fbc5-441e-9f3d-4409412e5bce)




