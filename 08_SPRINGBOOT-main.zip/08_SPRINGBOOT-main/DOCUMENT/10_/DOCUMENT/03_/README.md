

---
#
---

참고링크
---
> <br>

|-|
|-|
|[JSON->JAVA](https://json2csharp.com/code-converters/json-to-pojo)|
```

```

---
#
---

KAKAOMAP API
---
> <br>

|-|
|-|
|-|
|-|
|-|
|-|
|-|

```

```


---
#
---

KAKAOLOGINAPI 기본설정
---
> <br>

|-|
|-|

![20240511232126](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/0b7c419b-377f-4ff4-9de6-355cd525ad07)
![20240511232133](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/9ae76073-fadc-408e-b079-200e233432ce)
![20240511232140](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/0c4bac6f-2e97-4793-a12e-568397da9411)
![20240511232151](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/651dea62-ed64-40ec-bd6c-def4c3afd6e4)
![20240511232200](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/8905b10b-220d-48e2-8447-c483f6aa5e18)
![20240511232206](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/19e461e2-e19f-4290-8d90-e27a869b855a)
![20240512013846](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/f49d603f-37fe-4d08-8ca7-bb70a6405c7d)
![20240512013900](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/1ed02812-7110-4dda-8534-20f2fad7e650)
![20240512013906](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/0f10ff96-82ea-4f41-819f-bba4efd473cb)
![20240512013946](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/adfb21aa-df6f-4158-9a60-c0865ef2fdac)
![20240512014752](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/fc2056a3-ef6a-4186-b210-60df7d1f3d3d)
![20240512014802](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/f420bfbb-ae75-497a-9120-f714f4e19a0c)
![20240512014807](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/bf9de1d8-e63a-4574-9393-b2cf9e4b2119)
![20240512014818](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/c71700a8-9476-40fd-9918-b39b73902acc)
![20240512014824](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/bdfbb465-fe46-495b-b619-25f5923c2e55)
![20240512014834](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/ac15aadc-87fd-4570-9b1a-0c926ad22f74)
![20240512014842](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/d88300e7-4449-41c6-a24c-a5d89e81e27a)
![20240512014922](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/9eb7fdb2-4dce-4cb0-a3fd-d68a4b195898)
![20240512014931](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/66c03aed-a950-4502-9a04-65284a1948db)
![20240512014953](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/a9b2a019-91a4-40dd-a8b4-e4b1b98882ae)
![20240512015008](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/ee257486-c054-4969-8d5a-658fffd914b2)
![20240512015013](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/550885f2-a9cd-4a70-a290-f7a479ed25ce)
![20240512015039](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/e132a258-f805-4571-802c-70445c54af4e)
![20240512015044](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/f0249752-d21c-4805-bc6e-d8bb1091221c)
![20240512015049](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/a40a7725-3789-4bf7-a980-00e2183a8d97)
![20240512015059](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/97506f90-9019-4f1a-b96a-23f0c1205299)
![20240512015140](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/e65e7865-da54-49f8-984d-b191a2375f5b)
![20240512015244](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/893b1e3e-6cb7-4de9-8484-5114add378a2)
![20240512015250](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/92966919-1fd8-42c5-85ea-ebfb47dd9a75)
![20240512015309](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/4bab7224-c805-45c7-ba62-f9d6eca6003a)
![20240512015317](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/6a7c6406-454d-40d8-91e2-7dd40a6742f7)
![20240512015335](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/a589c7a9-6e5a-417a-9856-8e24afb959c5)


```

```


---
#
---

KAKAOLOGIN 인가코드 받기
---
> <br>

|-|
|-|
|[바로가기](https://developers.kakao.com/docs/latest/ko/kakaologin/rest-api#request-code)|


```

```

---
#
---

KAKAO PROFILE 가져오기
---
> <br>

|-|
|-|
|[바로가기](https://developers.kakao.com/docs/latest/ko/kakaologin/rest-api#req-user-info)|


```

```

---
#
---

KAKAO 나에게 메시지 보내기 
---
> <br>

|-|
|-|
|[바로가기](https://developers.kakao.com/docs/latest/ko/message/rest-api#custom-template-msg-me)|


```

```


---
#
---

로그아웃
---
> <br>

|-|
|-|
|[로그아웃](https://developers.kakao.com/docs/latest/ko/kakaologin/rest-api#logout)|
|[카카오계정과 함께 로그아웃](https://developers.kakao.com/docs/latest/ko/kakaologin/rest-api#logout-of-service-and-kakaoaccount)|
|[연결끊기](https://developers.kakao.com/docs/latest/ko/kakaologin/rest-api#unlink)|


![20240512030014](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/c8219702-b020-4966-bca1-5b1dd7d53425)
![20240512030022](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/d70c27a3-6370-4d28-ac03-a981783de442)
![20240512030059](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/e5da74ed-3e14-4e90-8897-9ececb51b171)
![20240512030106](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/ff527c29-14c4-4746-80c8-9ade6a01155b)


```

```


---
#
---

카카오 채널
---
> 관련링크<br>

|-|
|-|
|[카카오 채널 만들기](https://center-pf.kakao.com/profiles)|
|[카카오 채널 가입요청(JAVASCRIPT SDK)](https://developers.kakao.com/docs/latest/ko/kakaotalk-channel/js)|
|[개발문서 RESTFUL API](https://developers.kakao.com/product/kakaoTalkChannel)|
|[카카오 비즈니스](https://business.kakao.com/)|



> 카카오 일반채널 생성<br>

![20240512151602](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/b616c0c7-5cc7-46ef-9bff-219deddc16f5)
![20240512151609](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/12209a8d-2fa9-4ad1-af46-54fdcb50ca36)
![20240512151614](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/24ccce1b-034b-4147-8914-4b1e7804c4ce)
![20240512151740](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/38967176-6bb2-40e0-b1d2-8f70bf1523f2)
![20240512151756](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/c376afdd-fe89-4eeb-8eed-8ae4e31eb163)
![20240512151803](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/d472b01a-3532-4185-b13e-e92d61b83b98)
![20240512151818](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/75295aa0-813c-4b2e-a4e1-995bcd0f1f73)
![20240512151827](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/2aef3aee-c6d3-49f4-a3e1-bb3c8fd661c1)
![20240512151835](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/916387b5-7c4d-4d00-9ce9-543d538e2fb2)
![20240512151841](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/b273854b-5b99-45e3-acf5-32f609fc9070)
![20240512151845](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/03f6d199-940c-4f77-bc5e-9f192d40b689)


> 가입요청(JAVASCRIPT SDK)


---
#
---

TMP
---
> <br>

|-|
|-|
|<img src="" />|
|<img src="" />|
|<img src="" />|

```

```


---
#
---

TMP
---
> <br>

|-|
|-|
|<img src="" />|
|<img src="" />|
|<img src="" />|

```

```


---
#
---

TMP
---
> <br>

|-|
|-|
|<img src="" />|
|<img src="" />|
|<img src="" />|

```

```


---
#
---

TMP
---
> <br>

|-|
|-|
|<img src="" />|
|<img src="" />|
|<img src="" />|

```

```



