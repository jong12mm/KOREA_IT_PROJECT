

---
#
---

참고링크
---
> <br>

|-|
|-|
|[JSON->JAVA](https://json2csharp.com/code-converters/json-to-pojo)|
```

```


---
#
---

OPENWEATHERMAP API
---
> - <br>

|-|
|-|
| [OPENAPIMAP API SISTE](https://openweathermap.org/api)|



|-|
|-|
|<img  width=350px src="https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/1093110c-1c3a-408f-9d63-1e34d4fd93d5" />|
|<img  width=350px src="https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/212579aa-115e-4cd1-87a0-72f21af63731" />|

```
-
```
