

---
#
---

참고링크
---
> <br>

|-|
|-|
|[JSON->JAVA](https://json2csharp.com/code-converters/json-to-pojo)|
|[공공데이터포털](https://www.data.go.kr/)|
|[대구 맛집 API](https://www.data.go.kr/data/15057236/openapi.do)|

```

```


---
#
---

공공데이터 API
---
> - <br>

|-|
|-|
|-|


```

```
