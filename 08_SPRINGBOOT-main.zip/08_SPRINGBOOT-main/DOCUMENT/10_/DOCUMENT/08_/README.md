---
#
---

참고링크
---
> <br>

|-|
|-|
|[3.4.2 네이버 로그인 연동 URL 생성하기](https://developers.naver.com/docs/login/devguide/devguide.md#3-4-2-%EB%84%A4%EC%9D%B4%EB%B2%84-%EB%A1%9C%EA%B7%B8%EC%9D%B8-%EC%97%B0%EB%8F%99-url-%EC%83%9D%EC%84%B1%ED%95%98%EA%B8%B0)|
|[3.4.4 접근 토큰 발급 요청](https://developers.naver.com/docs/login/devguide/devguide.md#3-4-4-%EC%A0%91%EA%B7%BC-%ED%86%A0%ED%81%B0-%EB%B0%9C%EA%B8%89-%EC%9A%94%EC%B2%AD)|
|[3.4.5 접근 토큰을 이용하여 프로필 API 호출하기](https://developers.naver.com/docs/login/devguide/devguide.md#3-4-5-%EC%A0%91%EA%B7%BC-%ED%86%A0%ED%81%B0%EC%9D%84-%EC%9D%B4%EC%9A%A9%ED%95%98%EC%97%AC-%ED%94%84%EB%A1%9C%ED%95%84-api-%ED%98%B8%EC%B6%9C%ED%95%98%EA%B8%B0)|
|[연동 해제](https://developers.naver.com/docs/login/devguide/devguide.md#5-3-%EB%84%A4%EC%9D%B4%EB%B2%84-%EB%A1%9C%EA%B7%B8%EC%9D%B8-%EC%97%B0%EB%8F%99-%ED%95%B4%EC%A0%9C)|


---
#
---

네이버 개발자 센터 
---
> - <br>

![20240512161008](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/e6c5b413-8b32-4365-9d30-a57231e70dce) <br>
![20240512161020](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/6291f1a4-4192-45cb-8530-85ea319a1733) <br>
![20240512161024](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/8cd156e9-cdae-4908-b283-1097c2676f5c) <br>
![20240512161053](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/7c72b213-e963-49ea-a6c4-8e946e998d51) <br>
![20240512161059](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/6153790a-6a3e-4c1f-b7a4-60c996284f0b) <br>
![20240512161107](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/654cb6e5-7213-4ef2-b827-cb340137a36b) <br>
![20240512161111](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/9f25acf3-1488-44b3-94d6-0ba294d4acaf) <br>
![20240512161128](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/299efaac-8225-4cd3-9eae-1753a52b76e3) <br>
![20240512161133](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/33b934a5-c3ec-4021-bc1c-5a9309ba6fc3) <br>
![20240512161137](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/6383571e-c2c0-4c96-b37d-d1440bf7c523) <br>
![20240512161323](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/730806ab-d983-4062-9840-60efca043595) <br>
![20240512172912](https://github.com/MY-ALL-LECTURE/SPRINGBOOT/assets/84259104/dccfa207-80e6-4b5f-8f46-c27fd9cc0536) <br>






