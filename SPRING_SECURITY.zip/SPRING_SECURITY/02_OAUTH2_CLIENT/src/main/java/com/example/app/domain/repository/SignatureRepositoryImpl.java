package com.example.app.domain.repository;

public class SignatureRepositoryImpl {
}